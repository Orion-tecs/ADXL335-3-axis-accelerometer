This is a GUI written using Processing for an arduino based microcontroler that is using and anolog accelorometer. 
